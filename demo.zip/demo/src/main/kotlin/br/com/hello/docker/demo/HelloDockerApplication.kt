package br.com.hello.docker.demo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class HelloDockerApplication

fun main(args: Array<String>) {
	runApplication<HelloDockerApplication>(*args)
}
