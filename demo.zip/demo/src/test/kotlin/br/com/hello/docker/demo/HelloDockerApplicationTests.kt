package br.com.hello.docker.demo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HelloDockerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
